package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

public class TestProcedure {
	static Connection con = null;
	static Statement st =null;
	static ResultSet rs = null;
	static String querry = "INSERT INTO TBL_BOOKS_1190311 VALUES(105,'The secrets of nagas',250.5,436)";
	
public static void main(String[] args)
{
	DbTransaction Dbt1 = new DbTransaction("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","TBL_BOOK_1190311","aja10core","aja10core");
	HashMap<Integer,Book>Hm = new HashMap<Integer,Book>();
	Hm = getMapbyBookId(Dbt1);
	for(Integer k:Hm.keySet())
	{
		System.out.println("the book_id is:"+k+"the name is:"+Hm.get(k).getTitle());
	}

}
public static HashMap<Integer,Book> getMapbyBookId(DbTransaction dbt)
{
	HashMap<Integer,Book>Hm = new HashMap<Integer,Book>();
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con= DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","aja10core","aja10core");
		st = con.createStatement();
		//st.execute("INSERT INTO TBL_BOOK_1190311 VALUES(105,'The',250.5,436");
		st.executeUpdate(querry);
		rs = st.executeQuery("SELECT * FROM TBL_BOOKS_1190311");
		Book b = null;
		while(rs.next()){
		
			b = new Book(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getInt(4));
			
			Hm.put(rs.getInt(1),b);
		}
		con.commit();
		}catch(SQLException se){
		    //Handle errors for JDBC
		    se.printStackTrace();
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return Hm;
			
}
	
}

