package com;

public class AuthorDetails {
private String AuthorName;
private int pages;
private String city;
public String getAuthorName() {
	return AuthorName;
}
public void setAuthorName(String authorName) {
	AuthorName = authorName;
}
public int getPages() {
	return pages;
}
public void setPages(int pages) {
	this.pages = pages;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public AuthorDetails(String authorName, int pages, String city) {
	super();
	AuthorName = authorName;
	this.pages = pages;
	this.city = city;
}
public AuthorDetails() {
	super();
}

}
