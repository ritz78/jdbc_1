package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

public class TestProcedure {
	static Connection con = null;
	static Statement st =null;
	static ResultSet rs = null;
	//static String querry = "(INSERT INTO TBL_BOOKS_1190311 VALUES(10,'The secrets of nagas',250.5,436);";
	
public static void main(String[] args)
{
	DbTransaction Dbt1 = new DbTransaction("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","TBL_BOOK_1190311","aja10core","aja10core");
	HashMap<Integer,Book>Hm = new HashMap<Integer,Book>();
	Hm = getMapbyBookId(Dbt1);
	for(Integer k:Hm.keySet())
	{
		System.out.println("the book_id is:"+k+"the name is:"+Hm.get(k).getTitle());
	}

}
public static HashMap<Integer,Book> getMapbyBookId(DbTransaction dbt)
{
	HashMap<Integer,Book>Hm = new HashMap<Integer,Book>();
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con= DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","aja10core","aja10core");
		st = con.createStatement();
		/*st.executeUpdate("INSERT INTO TBL_BOOK_1190311 VALUES(101,'THE IMORTALS OF MELUHA',250.5,436)");
		st.executeUpdate("INSERT INTO TBL_BOOK_1190311 VALUES(102,'MIDNIGHT''S CHILDREN',324,647)");
		st.executeUpdate("INSERT INTO TBL_BOOK_1190311 VALUES(103,'THE SECRETS OF NAGAS',250,398)");
		st.executeUpdate("INSERT INTO TBL_BOOK_1190311 VALUES(104,'FURY',315,259)");
		st.executeUpdate("INSERT INTO TBL_BOOK_1190311 VALUES(105,' Harry Potter and the Philosopher''s Stone',750,336)");
		st.executeUpdate("INSERT INTO TBL_BOOK_1190311 VALUES(106,'Harry Potter and the Chamber of Secrets',650,300)");
		st.executeUpdate("INSERT INTO TBL_BOOK_1190311 VALUES(107,'REVOLUTION 2020',345.75,296)");
		st.executeUpdate("INSERT INTO TBL_BOOK_1190311 VALUES(108,'FIVE POINT SOMEONE',269,270)");*/

		//st.executeUpdate()
		//st.execute
		rs = st.executeQuery("SELECT * FROM TBL_BOOK_1190311 ORDER BY PRICE");
		Book b = null;
		while(rs.next()){
		
			b = new Book(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getInt(4));
			
			Hm.put(rs.getInt(1),b);
		}
		con.commit();
		}catch(SQLException se){
		    //Handle errors for JDBC
		    se.printStackTrace();
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return Hm;
			
}
	
}

