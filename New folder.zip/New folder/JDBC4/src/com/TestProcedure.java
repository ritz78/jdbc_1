package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class TestProcedure {
	static Connection con = null;
	static Statement st =null;
	static ResultSet rs = null;
	//static String querry = "(INSERT INTO TBL_BOOKS_1190311 VALUES(10,'The secrets of nagas',250.5,436);";
	
public static void main(String[] args)
{
	ArrayList<BookDetails> a = new ArrayList<BookDetails>();
	DbTransaction dbt = new DbTransaction("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","TBL_BOOK_1190311 ","TBL_AUTHOR_1190311 ","TBL_BOOK_AUTHOR_EMPID ","aja10core", "aja10core");
	a = getBookscountbyAuthor(dbt);
	for(BookDetails x:a)
		System.out.println("the author name is:"+x.getAuthorName()+"pages:"+x.getPages()+"the title is"+x.getBookTitle());
	
	

}
public static ArrayList<BookDetails> getBookscountbyAuthor(DbTransaction dbt)
{
	ArrayList<BookDetails> AL = new ArrayList<BookDetails>();
	String querry = "select b.title,b.pagenumber,a.name from tbl_book_1190311 b join tbl_book_author_empid c on b.book_id = c.book_id join tbl_author_1190311 a on a.author_id = c.author_id";
	
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con= DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","aja10core","aja10core");
		st = con.createStatement();
		
		rs = st.executeQuery(querry);
		BookDetails au = null;
		while(rs.next()){
		
			au = new BookDetails(rs.getString(3),rs.getString(1),rs.getInt(2));
			AL.add(au);
			
					}
		con.commit();
		}catch(SQLException se){
		    //Handle errors for JDBC
		    se.printStackTrace();
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	catch (Exception e)
	{
		e.printStackTrace();
	}
	
	return AL;
			
}
	
}

