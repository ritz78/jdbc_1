package com;

public class Department {
	private int deptId;
	private String deptName;
	private String deptOwner;
	public Department(int deptId, String deptName, String deptOwner) {
		super();
		this.deptId = deptId;
		this.deptName = deptName;
		this.deptOwner = deptOwner;
	}
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptOwner() {
		return deptOwner;
	}
	public void setDeptOwner(String deptOwner) {
		this.deptOwner = deptOwner;
	}
	

}
