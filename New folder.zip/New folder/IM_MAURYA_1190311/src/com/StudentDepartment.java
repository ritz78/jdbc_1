package com;

public class StudentDepartment {
	private String Student_name;
	private String StudentContact;
	private String deptName;
	private String deptOwner;
	public StudentDepartment(String student_name, String studentContact,
			String deptName, String deptOwner) {
		super();
		Student_name = student_name;
		StudentContact = studentContact;
		this.deptName = deptName;
		this.deptOwner = deptOwner;
	}
	public StudentDepartment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getStudent_name() {
		return Student_name;
	}
	public void setStudent_name(String student_name) {
		Student_name = student_name;
	}
	public String getStudentContact() {
		return StudentContact;
	}
	public void setStudentContact(String studentContact) {
		StudentContact = studentContact;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptOwner() {
		return deptOwner;
	}
	public void setDeptOwner(String deptOwner) {
		this.deptOwner = deptOwner;
	}
	

}
