package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class mainDemo {
	static Connection con = null;
	static Statement st =null;
	static PreparedStatement pst = null;
	static ResultSet rs = null;
	
	public static void main(String[] args) {
		
		DbTransaction db1 = new DbTransaction("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","TBL_DEPARTMENT_1190311","aja10core","aja10core");
		DbTransaction db2 = new DbTransaction("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","TBL_STUDENT_1190311","aja10core","aja10core");
		DbTransaction db = new DbTransaction("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","TBL_DEPARTMENT_1190311","TBL_STUDENT_1190311","aja10core","aja10core");
		
		
		Department d1 =new Department(1,"ece","kswfe");
		Department d2 =new Department(2,"eee","ksfr");
		
		Department d3 =new Department(3,"cse","ksadf");
		TestProcedure t1 = new TestProcedure();
		
		
		
		Student s1 = new Student(12, 1,"abi","hyderabad","abi@gmail.com");
		Student s2 = new Student(13, 1,"anu","chennai","abiqw@gmail.com");
		Student s3 = new Student(14, 3,"maurya","kochi","abiqq@gmail.com");
		Student s4 = new Student(15, 3,"vijay","hyderabad","abidwef@gmail.com");
		Student s5 = new Student(16, 2,"raj","delhi","abiwerf@gmail.com");
		
		System.out.println(t1.adddepartment(db1,d1));
		System.out.println(t1.adddepartment(db1,d2));
		System.out.println(t1.adddepartment(db1,d3));
		
		System.out.println(t1.addStudent(db2,s1));
		System.out.println(t1.addStudent(db2,s2));
		System.out.println(t1.addStudent(db2,s3));
		System.out.println(t1.addStudent(db2,s4));
		System.out.println(t1.addStudent(db2,s5));
		
		
		ArrayList<StudentDepartment> al = t1.displaystudentdepartment(db2,12);
		
		for(StudentDepartment s:al)
		{
			System.out.println(s.getStudent_name()+","+s.getDeptName());
		}
		
		t1.displayCountofStudentByDepartment(db);
		deleteTable(db);
		

	}
	public static void deleteTable(DbTransaction dx)
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","aja10core","aja10core");
			st = con.createStatement();
			st.executeUpdate("DROP"+dx);
			
	}catch(ClassCastException e)
	{
		e.printStackTrace();
	}catch(Exception ex)
	{
		ex.printStackTrace();
	}

}
}
	
