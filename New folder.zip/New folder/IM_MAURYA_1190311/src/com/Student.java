package com;

public class Student {
private int studentId;
private int deptId;
private String studentName;
private String StudentAddress;
private String StudentContact;
public Student(int studentId, int deptId, String studentName,
		String studentAddress, String studentContact) {
	super();
	this.studentId = studentId;
	this.deptId = deptId;
	this.studentName = studentName;
	StudentAddress = studentAddress;
	StudentContact = studentContact;
}
public Student() {
	super();
	// TODO Auto-generated constructor stub
}
public int getStudentId() {
	return studentId;
}
public void setStudentId(int studentId) {
	this.studentId = studentId;
}
public int getDeptId() {
	return deptId;
}
public void setDeptId(int deptId) {
	this.deptId = deptId;
}
public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
public String getStudentAddress() {
	return StudentAddress;
}
public void setStudentAddress(String studentAddress) {
	StudentAddress = studentAddress;
}
public String getStudentContact() {
	return StudentContact;
}
public void setStudentContact(String studentContact) {
	StudentContact = studentContact;
}

}
