package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class TestProcedure {
	static Connection con = null;
	static Statement st =null;
	static PreparedStatement pst = null;
	static ResultSet rs = null;
	
	public int adddepartment(DbTransaction dbt , Department dept)
	{
		int count=0;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","aja10core","aja10core");
			String query = "INSERT INTO"+dbt+" VALUES(?,?,?)";
			pst = con.prepareStatement(query);
			pst.setInt(1,dept.getDeptId());
			pst.setString(2,dept.getDeptName());
			pst.setString(3,dept.getDeptOwner());
			
			
			
			count = pst.executeUpdate();
					}catch(SQLException se){
		    		    se.printStackTrace();
		}catch(ClassCastException e)
		{
			e.printStackTrace();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return count;

	}
		
	
public int addStudent(DbTransaction dbt,Student stu)
{
	int count=0;
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","aja10core","aja10core");
		String query = "INSERT INTO"+dbt+" VALUES(?,?,?,?,?)";
		pst = con.prepareStatement(query);
		pst.setInt(1,stu.getStudentId());
		pst.setInt(2,stu.getDeptId());
		pst.setString(3,stu.getStudentName());
		pst.setString(4,stu.getStudentAddress());
		pst.setString(5,stu.getStudentContact());
		
		
		
		
		count = pst.executeUpdate();
				}catch(SQLException se){
	    		    se.printStackTrace();
	}catch(ClassCastException e)
	{
		e.printStackTrace();
	}catch(Exception ex)
	{
		ex.printStackTrace();
	}
	return count;

}
public ArrayList<StudentDepartment> displaystudentdepartment(DbTransaction dbt,int StudentId)
{
	ArrayList<StudentDepartment> sd = new ArrayList<StudentDepartment>();
	Student s = new Student();
	StudentDepartment sd1 =null;
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","aja10core","aja10core");
		st = con.createStatement();
		if(s.getStudentId()==StudentId)
		{
			rs = st.executeQuery("SELECT * FROM"+dbt);
			while(rs.next())
			{
				sd1 = new StudentDepartment(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
				sd.add(sd1);
			}
		}
	}catch(SQLException se){
		    se.printStackTrace();
}catch(ClassCastException e)
{
e.printStackTrace();
}catch(Exception ex)
{
ex.printStackTrace();
}
	
	return sd;
	
}
public void displayCountofStudentByDepartment(DbTransaction Dbt)
{
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","aja10core","aja10core");
		st = con.createStatement();
		rs = st.executeQuery("SELECT DEPT_NAME,COUNT(STUDENT_NAME) FROM [TBL_DEPARTMENT_1190311] D JOIN TBL_STUDENT_1190311 S ON D.DEPT_ID = S.DEPT_ID");
		while(rs.next())
		{
			System.out.println(rs.getString(1)+"-------"+rs.getInt(2));
		}
}catch(SQLException se){
    se.printStackTrace();
}catch(ClassCastException e)
{
e.printStackTrace();
}catch(Exception ex)
{
ex.printStackTrace();
}

}
}
