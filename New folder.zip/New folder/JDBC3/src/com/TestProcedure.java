package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class TestProcedure {
	static Connection con = null;
	static Statement st =null;
	static ResultSet rs = null;
	//static String querry = "(INSERT INTO TBL_BOOKS_1190311 VALUES(10,'The secrets of nagas',250.5,436);";
	
public static void main(String[] args)
{
	ArrayList<Author> a = new ArrayList<Author>();
	DbTransaction dbt = new DbTransaction("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","TBL_BOOK_1190311 ","TBL_AUTHOR_1190311 ","TBL_BOOK_AUTHOR_EMPID ","aja10core", "aja10core");
	a = getBookscountbyAuthor(dbt);
	for(Author x:a)
		System.out.println("the author name is:"+x.getAuthorname()+"the count of books :"+x.getCount());
	
	

}
public static ArrayList<Author> getBookscountbyAuthor(DbTransaction dbt)
{
	ArrayList<Author> AL = new ArrayList<Author>();
	String querry = "SELECT a.name,count (*) from tbl_author_1190311 a join tbl_book_author_empid b on a.author_id = b.author_id group by name";
	
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con= DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","aja10core","aja10core");
		st = con.createStatement();
		
		rs = st.executeQuery(querry);
		Author au = null;
		while(rs.next()){
		
			au = new Author(rs.getString(1), rs.getInt(2));
			AL.add(au);
			
					}
		con.commit();
		}catch(SQLException se){
		    //Handle errors for JDBC
		    se.printStackTrace();
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return AL;
			
}
	
}

