package com;

public class Author {
String Authorname;
int count;
public Author(String authorname, int count) {
	super();
	Authorname = authorname;
	this.count = count;
}
public String getAuthorname() {
	return Authorname;
}
public void setAuthorname(String authorname) {
	Authorname = authorname;
}
public int getCount() {
	return count;
}
public void setCount(int count) {
	this.count = count;
}
public Author() {
	super();
	// TODO Auto-generated constructor stub
}

}
