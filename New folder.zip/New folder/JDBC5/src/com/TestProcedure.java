package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class TestProcedure {
	static Connection con = null;
	static Statement st =null;
	static ResultSet rs = null;
	//static String querry = "(INSERT INTO TBL_BOOKS_1190311 VALUES(10,'The secrets of nagas',250.5,436);";
	
public static void main(String[] args)
{
	ArrayList<Book> a = new ArrayList<Book>();
	DbTransaction dbt = new DbTransaction("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","TBL_BOOK_1190311 ","TBL_AUTHOR_1190311 ","TBL_BOOK_AUTHOR_EMPID ","aja10core", "aja10core");
	a = getBookscountbyAuthor(dbt);
	for(Book x:a)
		System.out.println("the book_id:  "+x.getBook_id()+"title of the book:   "+x.getTitle()+"the price is   "+x.getPrice()+"the number of pages:   "+x.getPages());
	
	

}
public static ArrayList<Book> getBookscountbyAuthor(DbTransaction dbt)
{
	ArrayList<Book> AL = new ArrayList<Book>();
	String querry = "select * from tbl_book_1190311 order by price ";
	
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con= DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","aja10core","aja10core");
		st = con.createStatement();
		
		rs = st.executeQuery(querry);
		Book au = null;
		while(rs.next()){
		
			au = new Book(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getInt(4));
			AL.add(au);
			
					}
		con.commit();
		}catch(SQLException se){
		    //Handle errors for JDBC
		    se.printStackTrace();
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	catch (Exception e)
	{
		e.printStackTrace();
	}
	
	return AL;
			
}
	
}

