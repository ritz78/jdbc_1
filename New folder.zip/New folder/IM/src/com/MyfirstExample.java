package com;
//STEP 1. Import required packages
import java.sql.*;

public class MyfirstExample {
   // JDBC driver name and database URL
   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
   static final String DB_URL = "jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP";

   //  Database credentials
   static final String USER = "aja10core";
   static final String PASS = "aja10core";
   
   public static void main(String[] args) {
   Connection conn = null;
   Statement stmt = null;
   try{
      //STEP 2: Register JDBC driver
      Class.forName("oracle.jdbc.driver.OracleDriver");

      //STEP 3: Open a connection
      System.out.println("Connecting to database...");
      conn = DriverManager.getConnection(DB_URL,USER,PASS);

      //STEP 4: Execute a query
      System.out.println("Creating statement...");
      stmt = conn.createStatement();
      String sql;
      sql = "SELECT * FROM MAURYA";
      ResultSet rs = stmt.executeQuery(sql);

      //STEP 5: Extract data from result set
      int i=0;
      while(rs.next()){
         //Retrieve by column name
         int id  = rs.getInt(1);
         String name = rs.getString(2);
         int age = rs.getInt(3);
         String Stream = rs.getString(4);

         //Display values
         System.out.print("ID: " + id);
         System.out.print(", Age: " + age);
         System.out.print(", name: " +name );
         System.out.println(",Stream: " +Stream);
         i++;
      }
      System.out.println(i);
      //STEP 6: Clean-up environment
      rs.close();
      stmt.close();
      conn.close();
   }catch(SQLException se){
      //Handle errors for JDBC
      se.printStackTrace();
   }catch(Exception e){
      //Handle errors for Class.forName
      e.printStackTrace();
   }finally{
      //finally block used to close resources
      try{
         if(stmt!=null)
            stmt.close();
      }catch(SQLException se2){
      }// nothing we can do
      try{
         if(conn!=null)
            conn.close();
      }catch(SQLException se){
         se.printStackTrace();
      }//end finally try
   }//end try
   System.out.println("Goodbye!");
}//end main
}//end FirstExample
